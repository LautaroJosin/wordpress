<?php
// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;


// END ENQUEUE PARENT ACTION
add_action( 'wp_enqueue_scripts', 'theme_slug_enqueue_styles' );
function theme_slug_enqueue_styles() {
 
    $parent_style = 'oceanmp-style'; 
 
    wp_enqueue_style( $parent_style, get_template_directory_uri() . '/style.css' );
    wp_enqueue_style( 'child-style',
        get_stylesheet_directory_uri() . '/style.css',
        array( $parent_style ),
        wp_get_theme()->get('Version')
    );
}


/**
 * Alter your post layouts
 *
 * Replace is_singular( 'post' ) by the function where you want to alter the layout
 * You can also use is_page ( 'page name' ) to alter layouts on specific pages
 * @return full-width, full-screen, left-sidebar, right-sidebar or both-sidebars
 *
 */
function my_post_layout_class( $class ) {

	// Alter your layout
	if ( is_singular( 'personal' ) ) {
		$class = 'full-width';
	}

	// Return correct class
	return $class;

}
add_filter( 'ocean_post_layout_class', 'my_post_layout_class', 20 );









// shortcode1

function shortcode1() {
    echo "Holaaaaa lauti";  
}

add_shortcode('algo','shortcode1');

// shortcode2

function shortcode2($atts){
    $atts = shortcode_atts (
            array ( 'nombre' => 'lautaro',
                    'apellido' => 'josin',
                    'edad' => 18
                ) , $atts ); 

    return "Hola, soy ".$atts['nombre']." ".$atts['apellido']." y tengo ".$atts['edad'];
}

add_shortcode('mostrar-nombre','shortcode2');